<?php

function is_input_empty($email, $password) {
    return empty($email) || empty($password);
}

function is_email_wrong($result) {
    return empty($result);
}

function is_password_wrong($password, $hashedPassword) {
    return !password_verify($password, $hashedPassword);
}

