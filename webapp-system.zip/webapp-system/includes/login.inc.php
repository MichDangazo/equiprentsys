<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = isset($_POST["email"]) ? $_POST["email"] : '';
    $password = isset($_POST["password"]) ? $_POST["password"] : '';

    echo "Script started.<br>";
    echo "Form submitted.<br>";
    echo "Email: " . htmlspecialchars($email) . "<br>";
    echo "Password: " . htmlspecialchars($password) . "<br>";

    try {
        require_once 'dbh.inc.php';
        require_once 'login_model.inc.php';
        require_once 'login_contr.inc.php';

        echo "Required files included.<br>";

        // ERROR HANDLERS
        $errors = [];

        if (is_input_empty($email, $password)) {
            $errors["empty_input"] = "Fill in all fields!";
            echo "Input is empty.<br>";
        }

        $result = get_user($pdo, $email);

        echo "Result from get_user: " . json_encode($result) . "<br>";

        if (!$result) {
            $errors["login_incorrect"] = "Incorrect login info!";
            echo "No user found with this email.<br>";
        } else {
            if (is_password_wrong($password, $result["password"])) {
                $errors["login_incorrect"] = "Incorrect login info!";
                echo "Password verification failed.<br>";
            } else {
                echo "Password verification succeeded.<br>";
            }
        }

        echo "Errors: " . json_encode($errors) . "<br>";

        require_once 'config_session.inc.php';

        if ($errors) {
            $_SESSION["errors_login"] = $errors;
            header("Location: ../index.php");
            die();
        }

        $newSessionId = session_create_id();
        $sessionId = $newSessionId . "_" . $result["id"];
        session_id($sessionId);

        $_SESSION["user_id"] = $result["id"];
        $_SESSION["user_email"] = htmlspecialchars($result["email"]);
        $_SESSION["last_regeneration"] = time();

        header("Location: ../dashboard.php");
        $pdo = null;
        $stmt = null;

        die();
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../index.php");
    die();
}
?>
