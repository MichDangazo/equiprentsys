<?php

declare(strict_types=1);

function get_email(object $pdo, string $email)
{
    $query = "SELECT email FROM users WHERE email = :email;";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":email", $email);
    $stmt->execute();

    $eresults = $stmt->fetch(PDO::FETCH_ASSOC);
    return $eresults;
}

function set_user(object $pdo, string $firstName, string $lastName, string $email, string $password) 
{
    echo "Preparing to insert user...<br>";

    $query = "INSERT INTO users (firstName, lastName, email, password) VALUES (:firstName, :lastName, :email, :password);";
    $stmt = $pdo->prepare($query);

    $options = [
        'cost' => 12
    ];
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT, $options);

    echo "Query prepared: $query<br>";
    echo "FirstName: $firstName, LastName: $lastName, Email: $email, Password: $hashedPassword<br>";

    $stmt->bindParam(":firstName", $firstName);
    $stmt->bindParam(":lastName", $lastName);
    $stmt->bindParam(":email", $email);
    $stmt->bindParam(":password", $hashedPassword);

    if ($stmt->execute()) {
        echo "User inserted successfully.";
    } else {
        $errorInfo = $stmt->errorInfo();
        echo "Error inserting user: " . implode(" ", $errorInfo) . "<br>";
    }
}

function create_user($pdo, $firstName, $lastName, $email, $password) {
    echo "Creating user...<br>";
    set_user($pdo, $firstName, $lastName, $email, $password);
    echo "User created!<br>";
}