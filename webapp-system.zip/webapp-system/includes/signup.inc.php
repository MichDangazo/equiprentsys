<?php

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $firstName = isset($_POST["firstName"]) ? $_POST["firstName"] : '';
    $lastName = isset($_POST["lastName"]) ? $_POST["lastName"] : '';
    $email = isset($_POST["email"]) ? $_POST["email"] : '';
    $password = isset($_POST["password"]) ? $_POST["password"] : '';

    try {
        require_once 'dbh.inc.php';
        require_once 'signup_model.inc.php';
        require_once 'signup_contr.inc.php';

        // ERROR HANDLERS
        $errors = [];


        if (is_input_empty($firstName, $lastName, $email, $password)) {
            $errors["empty_input"] = "Fill in all fields!";
        }
        if (is_email_invalid($email)) {
            $errors["invalid_input"] = "Invalid email used!";
        }
        if (is_email_taken($pdo, $email)) {
            $errors["email_taken"] = "Email already taken!";
        }
        if (is_email_registered($pdo, $email)) {
            $errors["email_used"] = "Email already registered!";
        }

        require_once 'config_session.inc.php';


        if ($errors) {
            $_SESSION["error_signup"] = $errors;
            header("Location: ../index.php");
            die();
        }

        create_user($pdo, $firstName, $lastName, $email, $password);

        header("Location: ../index.php?signup=success");

        $pdo = null;
        $stmt = null;

        die();
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    echo "Form not submitted.<br>";
    header("Location: ../index.php");
    die();
}