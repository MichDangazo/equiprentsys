<?php
require_once 'includes/config_session.inc.php';
require_once 'includes/signup_view.inc.php';
require_once 'includes/login_view.inc.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Login and Signup</title>
</head>

<body>
        <div class="container">
            <div class="form-wrapper">
                <div class="tab">
                    <button class="tablinks" onclick="openForm(event, 'Login')" id="defaultOpen">Login</button>
                    <button class="tablinks" onclick="openForm(event, 'Signup')">Signup</button>
                </div>

            <form action="includes/login.inc.php" method="POST">
                <div id="Login" class="tabcontent">
                    <form id="login-form">
                        <h2>Login Form</h2>
                        <label for="login-email">Email Address:</label>
                        <input type="email" id="login-email" name="email" placeholder="Email Address">
                    
                        <label for="login-password">Password:</label>
                        <input type="password" id="login-password" name="password" placeholder="Password">
                    
                        <button type="submit">Login</button>
                    
                        <p>Not a member? <a href="#" onclick="openForm(event, 'Signup')">Signup now</a></p>
                    </form>
                </div>
            </form>

    <?php
    check_signup_errors();
    check_login_errors();
    ?>

            <form action="includes/signup.inc.php" method="POST">
                <div id="Signup" class="tabcontent">
                    <form id="signup-form">
                        <h2>Signup Form</h2>

                        <label for="signup-firstName">First Name:</label>
                        <input type="text" id="signup-firstName" name="firstName" placeholder="First Name">
                        
                        <label for="signup-lastName">Last Name:</label>
                        <input type="text" id="signup-lastName" name="lastName" placeholder="Last Name">
                        
                        <label for="signup-email">Email address:</label>
                        <input type="email" id="signup-email" name="email" placeholder="Email address">
                        
                        <label for="signup-password">Password:</label>
                        <input type="password" id="signup-password" name="password" placeholder="Password">
                        
                        <button type="submit">Signup</button>
                        
                        <p>Already a member? <a href="#" onclick="openForm(event, 'Login')">Login now</a></p>
                    </form>
                </div>
            </div>
        </div>
            </form>

        <script>
            function openForm(evt, formName) {
                var i, tabcontent, tablinks;
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }

                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }
                document.getElementById(formName).style.display = "block";
                evt.currentTarget.className += " active";
            }

            document.getElementById("defaultOpen").click();
        </script>

    <?php
    check_signup_errors();
    check_login_errors();
    ?>

</body>

</html>