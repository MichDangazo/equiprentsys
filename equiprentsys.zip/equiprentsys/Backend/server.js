const express = require('express');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json()); // Add this to parse JSON request bodies

// Sample route to test server
app.get('/', (req, res) => {
  return res.json({ message: "Hello world" });
});

// Signup route
app.post('/signup', (req, res) => {
  const { email, password } = req.body;

  // Assuming you have a users array or a database setup
  const users = []; // This is a placeholder. Replace with your actual user data storage

  if (users.find(u => u.email === email)) {
    return res.status(400).send({ message: 'User already exists' });
  }

  // Simulate password hashing and storing the new user
  const hashedPassword = password; // Use bcrypt or another hashing library
  const newUser = { id: users.length + 1, email, password: hashedPassword };
  users.push(newUser);

  res.status(201).send({ message: 'User created successfully' });
});

app.listen(8081, () => {
  console.log('listening on port 8081');
});
