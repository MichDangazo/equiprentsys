<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <link rel="stylesheet" href="css/styles.css">
</head>

<body>
    <header>
        <nav>
            <div class="logo">InventoryTrack</div>
        </nav>
    </header>

    <h1>Inventory Management System</h1>

    <main>
        <h2>Available Equipments</h2>
        <section class="products">
            <div class="product-card">
            <img src="assets\articulated.jpg" alt="articulated">
            <div class="product-info">
                    <h3>Articulated Truck</h3>
                    <p>Model: Volvo A40G</p>
                    <p>Weekly Rate: $3900.00</p>
                    <p>Supplier: Gracethorne Manor</p>
                </div>
            </div>
            <div class="product-card">
                <img src="assets\compactor.jpg" alt="compactor">
                <div class="product-info">
                    <h3>Compactor</h3>
                    <p>Model: Bomag BW213DH-5</p>
                    <p>Weekly Rate: $1000.00</p>
                    <p>Supplier: Avonnia Harbor</p>
                </div>
            </div>
            <div class="product-card">
            <img src="assets\excavator.jpg" alt="excavator">
            <div class="product-info">
                    <h3>Excavator</h3>
                    <p>Model: Komatsu PC210LC-11</p>
                    <p>Weekly Rate: $2100.00</p>
                    <p>Supplier: Gracethorne Manor</p>
                </div>
            </div>
            <div class="product-card">
            <img src="assets\grader.jpg" alt="grader">
            <div class="product-info">
                    <h3>Grader</h3>
                    <p>Model: Caterpillar 140M3</p>
                    <p>Weekly Rate: $3500.00</p>
                    <p>Supplier: Wraith Garden Obelisk</p>
                </div>
            </div>
            <div class="product-card">
            <img src="assets\loader.jpg" alt="loader">
            <div class="product-info">
                    <h3>Loader</h3>
                    <p>Model: John Deere 644K</p>
                    <p>Weekly Rate: $1000.00</p>
                    <p>Supplier: Avonnia Harbor</p>
                </div>
            </div>
            <div class="product-card">
            <img src="assets\scraper.png" alt="scraper">
            <div class="product-info">
                    <h3>Scraper</h3>
                    <p>Model: Caterpillar 637K</p>
                    <p>Weekly Rate: $7000.00</p>
                    <p>Supplier: Wraith Garden Obelisk</p>
                </div>
        </section>
        <button class="see-more">See more</button>
    </main>

    <h2>Add New Rental Order</h2>

    <form action="includes\insert.inc.php" method="POST">
        <label for="customerID">Customer ID:</label>
        <input type="text" name="customerID" placeholder="Customer ID" required><br>

        <label for="employeeID">Employee ID:</label>
        <input type="text" name="employeeID" placeholder="Employee ID" required><br>

        <label for="rentalStartDate">Rental Start Date:</label>
        <input type="date" name="rentalStartDate" required><br>

        <label for="rentalEndDate">Rental End Date:</label>
        <input type="date" name="rentalEndDate" required><br>

        <label for="equipmentType">Equipment Type:</label>
        <input type="text" name="equipmentType" placeholder="Equipment Type" required><br>

        <button type="submit">Add Order</button>
    </form>

    <h2>Active Rental Orders</h2>

    <?php
include 'includes/dbh.inc.php';

try {
    $sql = "SELECT * FROM active_rents";
    $stmt = $pdo->query($sql);

    // Fetch all data to debug
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo '<pre>';

    if ($stmt->rowCount() > 0) {
        echo "<table border='1'>";
        echo "<thead>";
        echo "<tr>
                <th>Customer's Name</th>
                <th>Employee's Name in charge</th>
                <th>Rent Start Date</th>
                <th>Rent End Date</th>
                <th>Total Cost</th>
                <th>Rented Equipment</th>
              </tr>";
        echo "</thead>";
        echo "<tbody>";

        foreach ($data as $row) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row["Customer's Name"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Employee's name in charge"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Rent Start Date"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Rent End Date"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Total Cost"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Rented Equipment"] ?? 'N/A') . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No active rental orders found.</p>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>


<h2>Suppliers</h2>
    <section class="products">
        <div class="product-card">
            <img src="assets/GM.jpg" alt="Gracethorne Manor">
            <div class="product-info">
                <h3>Gracethorne Manor</h3>
                <p>Contact Person: Ashton Graceworth</p>
                <p>Phone: +46 84319576</p>
                <p>Address: Gothenburg, Sweden</p>
            </div>
        </div>
        <div class="product-card">
            <img src="assets/AH.jpg" alt="Avonnia Harbor">
            <div class="product-info">
                <h3>Avonnia Harbor</h3>
                <p>Contact Person: Aira Chandelle</p>
                <p>Phone: +39 75321598</p>
                <p>Address: Venice, Veneto region, Italy</p>
            </div>
        </div>
        <div class="product-card">
            <img src="assets/WGO.jpg" alt="Wraith Garden Obelisk">
            <div class="product-info">
                <h3>Wraith Garden Obelisk</h3>
                <p>Contact Person: Alistair/Angelica Tayloure</p>
                <p>Phone: (949) 555 8426</p>
                <p>Address: Los Angeles, California, United States</p>
            </div>
        </div>
    </section>

    <h2>Other Records</h2>
    <section class="button-section">
        <div class="button-card">
            <form action="includes\availequip.inc.php" method="POST">
                <button type="submit" class="availEquip">AVAILABLE EQUIPMENTS</button>
            </form>
        </div>
        <div class="button-card">
            <form action="includes\customers.inc.php" method="POST">
                <button type="submit" class="customer">ADD CUSTOMER</button>
            </form>
        </div>
        <div class="button-card">
            <form action="includes\reports.inc.php" method="POST">
                <button class="view-reports">VIEW REPORTS</button>
            </form>
        </div>
    </section>
</body>
</html>