<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <link rel="stylesheet" href="../css/availequip.sty.css">
</head>
<body>
    <main>
        <h2>Available Equipments</h2>
        <section class="products">
            <div class="product-card">
                <img src="../assets/articulated.jpg" alt="articulated">
                <div class="product-info">
                    <h3>Articulated Truck</h3>
                    <p>Model: Volvo A40G</p>
                    <p>Weekly Rate: $3900.00</p>
                    <p>Supplier: Gracethorne Manor</p>
                </div>
            </div>
            <div class="product-card">
                <img src="../assets/compactor.jpg" alt="compactor">
                <div class="product-info">
                    <h3>Compactor</h3>
                    <p>Model: Bomag BW213DH-5</p>
                    <p>Weekly Rate: $1000.00</p>
                    <p>Supplier: Avonnia Harbor</p>
                </div>
            </div>
            <div class="product-card">
                <img src="../assets/excavator.jpg" alt="excavator">
                <div class="product-info">
                    <h3>Excavator</h3>
                    <p>Model: Komatsu PC210LC-11</p>
                    <p>Weekly Rate: $2100.00</p>
                    <p>Supplier: Gracethorne Manor</p>
                </div>
            </div>
            <div class="product-card">
                <img src="../assets/grader.jpg" alt="grader">
                <div class="product-info">
                    <h3>Grader</h3>
                    <p>Model: Caterpillar 140M3</p>
                    <p>Weekly Rate: $3500.00</p>
                    <p>Supplier: Wraith Garden Obelisk</p>
                </div>
            </div>
            <div class="product-card">
                <img src="../assets/loader.jpg" alt="loader">
                <div class="product-info">
                    <h3>Loader</h3>
                    <p>Model: John Deere 644K</p>
                    <p>Weekly Rate: $1000.00</p>
                    <p>Supplier: Avonnia Harbor</p>
                </div>
            </div>
            <div class="product-card">
                <img src="../assets/scraper.png" alt="scraper">
                <div class="product-info">
                    <h3>Scraper</h3>
                    <p>Model: Caterpillar 637K</p>
                    <p>Weekly Rate: $7000.00</p>
                    <p>Supplier: Wraith Garden Obelisk</p>
                </div>
            </div>
        </section>
        <h2>Rented Equipments</h2>
        <section class="products">
            <div class="product-card">
                <img src="../assets/crane.jpg" alt="crane">
                <div class="product-info">
                    <h3>Crane</h3>
                    <p>Model: Liebherr LTM 11200-9.1</p>
                    <p>Weekly Rate: $5000.00</p>
                    <p>Supplier: Avonnia Harbor</p>
                </div>
            </div>
            <div class="product-card">
                <img src="../assets\dump_truck.jpg" alt="dump_truck">
                <div class="product-info">
                    <h3>Dump Truck</h3>
                    <p>Model: Caterpillar 797F</p>
                    <p>Weekly Rate: $2400.00</p>
                    <p>Supplier: Wraith Garden Obelisk</p> 
                </div>
            </div>
            <div class="product-card">
                <img src="../assets/dozer.jpeg" alt="dozer">
                <div class="product-info">
                    <h3>Dozer</h3>
                    <p>Model: Caterpillar D8T</p>
                    <p>Weekly Rate: $3500.00</p>
                    <p>Supplier: Wraith Garden Obelisk</p>
                </div>
            </div>
            <div class="product-card">
                <img src="../assets/grader.jpg" alt="grader">
                <div class="product-info">
                    <h3>Trailer</h3>
                    <p>Model: Fontaine Magnitude 55MX</p>
                    <p>Weekly Rate: $600.00</p>
                    <p>Supplier: Gracethorne Manor</p>
                </div>
            </div>
    </main>
</body>
</html>
