<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <link rel="stylesheet" href="../css/customers.sty.css">
</head>

<body>

<h2>Add New Rental Order</h2>

    <label for="firstName">First Name:</label>
    <input type="text" name="firstName" placeholder="First Name" required><br>

    <label for="lastName">Last Name:</label>
    <input type="text" name="lastName" placeholder="Last Name" required><br>

    <label for="companyName">Company Name:</label>
    <input type="text" name="companyName" placeholder="Company Name" required><br>

    <label for="Address">Address:</label>
    <input type="text" name="Address" placeholder="Address" required><br>

    <label for="Phone">Phone:</label>
    <input type="text" name="Phone" placeholder="Phone" required><br>

    <label for="Email">Email:</label>
    <input type="text" name="Email" placeholder="Email" required><br>

    <button type="submit">Add Customer</button>
</form>

<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve POST data
    $firstName = $_POST["customerID"];
    $lastName = $_POST["employeeID"];
    $companyName = $_POST["rentalStartDate"];
    $Address = $_POST["rentalEndDate"];
    $Phone = $_POST["equipmentType"];

    try {
        // Include database connection
        require_once 'dbh.inc.php';

        // Insert order into orders table
        $query = "INSERT INTO orders (CustomerID, EmployeeID, RentalStartDate, RentalEndDate, TotalCost, Status) VALUES (?, ?, ?, ?, 0, 1)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$customerID, $employeeID, $rentalStartDate, $rentalEndDate]);

        // Get the last inserted order ID
        $orderID = $pdo->lastInsertId();

        // Insert equipment into orderequipment table
        $query = "INSERT INTO orderequipment (OrderID, EquipmentID) 
                  SELECT ?, EquipmentID FROM equipment WHERE EquipmentType = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$orderID, $equipmentType]);

        // Close connection
        $pdo = null;
        $stmt = null;

        // Redirect to index page
        header("Location: ../index.php");
        exit();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}

?>

</body>
</html>