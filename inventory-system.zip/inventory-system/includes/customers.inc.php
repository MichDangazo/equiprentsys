<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <link rel="stylesheet" href="../css/customers.sty.css">
</head>
<body>

<h2>Add New Customer</h2>

<form action="customers.inc.php" method="post">
    <label for="firstName">First Name:</label>
    <input type="text" name="firstName" placeholder="First Name" required><br>

    <label for="lastName">Last Name:</label>
    <input type="text" name="lastName" placeholder="Last Name" required><br>

    <label for="companyName">Company Name:</label>
    <input type="text" name="companyName" placeholder="Company Name" required><br>

    <label for="address">Address:</label>
    <input type="text" name="address" placeholder="Address" required><br>

    <label for="phone">Phone:</label>
    <input type="text" name="phone" placeholder="Phone" required><br>

    <label for="email">Email:</label>
    <input type="text" name="email" placeholder="Email" required><br>

    <button type="submit">Add Customer</button>
</form>

<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve POST data
    $firstName = $_POST["firstName"] ?? '';
    $lastName = $_POST["lastName"] ?? '';
    $companyName = $_POST["companyName"] ?? '';
    $address = $_POST["address"] ?? '';
    $phone = $_POST["phone"] ?? '';
    $email = $_POST["email"] ?? '';

    try {
        // Include database connection
        require_once '../includes/dbh.inc.php';

        // Call stored procedure to add customer
        $query = "CALL add_customer(?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$firstName, $lastName, $companyName, $address, $phone, $email]);

        // Close connection
        $pdo = null;
        $stmt = null;

        echo "<p>Customer added successfully!</p>";
    } catch (PDOException $e) {
        echo "<p>Error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "Invalid request method.";
}

?>

</body>
</html>
