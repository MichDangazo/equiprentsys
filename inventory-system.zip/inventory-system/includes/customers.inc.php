<?php

include 'includes/dbh.inc.php';

    try {
        $sql = "SELECT * FROM customers";
        $stmt = $pdo->query($sql);
        if ($stmt->rowCount() > 0) {
            echo "<table>";
            echo "<tr><th>FirstName</th><th>LastName</th><th>CompanyName</th><th>Address</th><th>Phone</th><th>Email</th></tr>";
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['FirstName']) . "</td>";
                echo "<td>" . htmlspecialchars($row['LastName']) . "</td>";
                echo "<td>" . htmlspecialchars($row['CompanyName']) . "</td>";
                echo "<td>" . htmlspecialchars($row['Address']) . "</td>";
                echo "<td>" . htmlspecialchars($row['Phone']) . "</td>";
                echo "<td>" . htmlspecialchars($row['Email']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No customers found.</p>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }