<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve POST data
    $customerID = $_POST["customerID"];
    $employeeID = $_POST["employeeID"];
    $rentalStartDate = $_POST["rentalStartDate"];
    $rentalEndDate = $_POST["rentalEndDate"];
    $equipmentType = $_POST["equipmentType"];

    try {
        // Include database connection
        require_once 'dbh.inc.php';

        // Insert order into orders table
        $query = "INSERT INTO orders (CustomerID, EmployeeID, RentalStartDate, RentalEndDate, TotalCost, Status) VALUES (?, ?, ?, ?, 0, 1)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$customerID, $employeeID, $rentalStartDate, $rentalEndDate]);

        // Get the last inserted order ID
        $orderID = $pdo->lastInsertId();

        // Insert equipment into orderequipment table
        $query = "INSERT INTO orderequipment (OrderID, EquipmentID) 
                  SELECT ?, EquipmentID FROM equipment WHERE EquipmentType = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$orderID, $equipmentType]);

        // Close connection
        $pdo = null;
        $stmt = null;

        // Redirect to index page
        header("Location: ../index.php");
        exit();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}
