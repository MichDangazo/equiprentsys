<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customerID = $_POST["customerID"];
    $employeeID = $_POST["employeeID"];
    $rentalStartDate = $_POST["rentalStartDate"];
    $rentalEndDate = $_POST["rentalEndDate"];
    $equipmentType = $_POST["equipmentType"];

    try {
        require_once 'dbh.inc.php';

        $query = "INSERT INTO orders (CustomerID, EmployeeID, RentalStartDate, RentalEndDate, TotalCost, Status) VALUES (?, ?, ?, ?, 0, 1)";
        
        $stmt = $pdo->prepare($query);
        
        $stmt->execute([$customerID, $employeeID, $rentalStartDate, $rentalEndDate]);

        $orderID = $pdo->lastInsertId();

        $query = "INSERT INTO orderequipment (OrderID, EquipmentID) SELECT ?, EquipmentID FROM equipment WHERE EquipmentType = ?";

        $stmt = $pdo->prepare($query);

        $stmt->execute([$equipmentType]);

        $pdo = null;
        $stmt = null;

        header("Location: ../index.php");

        die();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid request method.";
}