<?php

include 'includes/dbh.inc.php';

    try {
        $sql = "SELECT * FROM reports";
        $stmt = $pdo->query($sql);
        if ($stmt->rowCount() > 0) {
            echo "<table>";
            echo "<tr><th>ReportType</th><th>GeneratedDate</th><th>Content</th></tr>";
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['ReportType']) . "</td>";
                echo "<td>" . htmlspecialchars($row['GeneratedDate']) . "</td>";
                echo "<td>" . htmlspecialchars($row['Content']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No reports found.</p>";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }