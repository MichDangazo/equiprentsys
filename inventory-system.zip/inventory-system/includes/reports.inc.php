<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management System</title>
    <link rel="stylesheet" href="../css/reports.sty.css">
</head>
<body>

<main>
        <h2>Rental Reports</h2>
        <section class="products">
            <div class="product-card">
            <div class="product-info">
            </div>
        </div>
        </section>

<?php
include 'dbh.inc.php'; // Corrected path

try {
    $sql = "SELECT * FROM rental_reports";
    $stmt = $pdo->query($sql);

    if ($stmt->rowCount() > 0) {
        echo "<table border='1'>";
        echo "<thead>";
        echo "<tr>
                <th>Report Subject</th>
                <th>Generated Date</th>
                <th>Content</th>
                <th>Employee's Name</th>
                <th>Role</th>
              </tr>";
        echo "</thead>";
        echo "<tbody>";

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row["Report Subject"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Generated Date"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Content"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Employee's Name"] ?? 'N/A') . "</td>";
            echo "<td>" . htmlspecialchars($row["Role"] ?? 'N/A') . "</td>";
            echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No reports found.</p>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

</div>
</section>

</body>
</html>
